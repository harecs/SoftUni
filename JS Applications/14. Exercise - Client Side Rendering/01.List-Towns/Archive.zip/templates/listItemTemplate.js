import { html } from "../node_modules/lit-html/lit-html.js";

export const listItemTemplate = (town) => {
    return html`<li>${town}</li>`;
}